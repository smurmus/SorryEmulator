package sorryclient;

public interface Listener {
	public void listen(String msg);
}
