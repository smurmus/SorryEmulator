package customUI;

import java.awt.Color;

import javax.swing.JPanel;

public class ClearPanel extends JPanel{
	private static final long serialVersionUID = 8217343096830713727L;

	{
		setBackground(new Color(0,0,0,0));
		setOpaque(true);
	}
}
